<div class="intro">
    <h1>Rabithah Thaliban Aceh</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis, accusamus voluptates adipisci, minima
        architecto nostrum quo aspernatur cumque animi voluptate necessitatibus excepturi nesciunt! Praesentium
        ea eveniet tempora, tenetur similique cupiditate.</p>
    <p>Let's Go......</p>
</div>
<div class="brosur">
    <!-- <div>
                <h2>Brosur..</h2>
            </div> -->
    <!-- <img src="/docs/brosur.png" alt="Brosur"> -->
</div>