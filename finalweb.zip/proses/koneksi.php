<?php
$conn = mysqli_connect("localhost", "root", "", "spacedev")
    or die("koneksi gagal");
?>