    <div class="navbar">
        <div class="logo">
            <a href=""><img src="docs/logo.png" alt=""></a>
        </div>
        <div class="search">
            <img src="docs/search_icon.png" alt="">
            <form action="">
                <input type="text" name="search" id="all_search" placeholder="Search..">
            </form>
        </div>
        <ul>
            <li><a href="facebook"><img src="docs/facebook.png" alt=""></a></li>
            <li><a href="twiter"><img src="docs/twiter.png" alt=""></a></li>
            <li><a href="instagram"><img src="docs/instagram.png" alt=""></a></li>
            <li><a href="youtube"><img src="docs/youtube.png" alt="youtube"></a></li>
        </ul>
    </div>
    <hr class="line">
    <ul class="down_navbar">
        <li><a class="active" href="home">Home</a></li>
        <li><a href="about">About</a></li>
        <li><a href="blog">Blog</a></li>
        <li><a href="member">Member</a></li>
        <li><a href="profile">Profile</a></li>
        <li><a href="logout">Sign-in/Logout</a></li>
    </ul>